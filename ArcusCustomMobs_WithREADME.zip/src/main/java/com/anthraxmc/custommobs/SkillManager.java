package com.arcusmc.custommobs;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;

public class SkillManager {

    public static void castExplosionSkill(LivingEntity caster) {
        Location loc = caster.getLocation();
        loc.getWorld().createExplosion(loc, 2F, false);
    }

    public static void castLightningSkill(LivingEntity caster) {
        caster.getWorld().strikeLightning(caster.getLocation());
    }

    public static void heal(LivingEntity entity, double amount) {
        double newHealth = Math.min(entity.getMaxHealth(), entity.getHealth() + amount);
        entity.setHealth(newHealth);
    }

    public static void broadcastMessage(String message) {
        Bukkit.broadcastMessage("§c[Skill]: §7" + message);
    }
}
