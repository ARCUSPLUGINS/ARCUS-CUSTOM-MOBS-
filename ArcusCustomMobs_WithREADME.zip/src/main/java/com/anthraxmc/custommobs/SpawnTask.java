package com.arcusmc.custommobs;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Random;

public class SpawnTask extends BukkitRunnable {

    private final JavaPlugin plugin;
    private final MobManager mobManager;
    private final Random random = new Random();

    public SpawnTask(JavaPlugin plugin, MobManager mobManager) {
        this.plugin = plugin;
        this.mobManager = mobManager;
    }

    @Override
    public void run() {
        for (World world : Bukkit.getWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                if (random.nextDouble() < 0.05) {
                    mobManager.spawnCustomMob(chunk.getBlock(8, chunk.getWorld().getHighestBlockYAt(chunk.getBlock(8, 0, 8).getLocation()), 8).getLocation(), "zombie");
                }
            }
        }
    }
}
