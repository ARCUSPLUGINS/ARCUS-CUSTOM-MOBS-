package com.arcusmc.custommobs;

import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Random;

public class LootManager {

    private static final Random random = new Random();

    public static void handleDeath(EntityDeathEvent event) {
        Entity entity = event.getEntity();
        if (entity.getCustomName() != null && entity.getCustomName().contains("Zombie")) {
            if (random.nextDouble() < 0.3) {
                ItemStack drop = new ItemStack(Material.DIAMOND_SWORD);
                ItemMeta meta = drop.getItemMeta();
                meta.setDisplayName("§cBlood Blade");
                drop.setItemMeta(meta);
                event.getDrops().add(drop);
            }
        }
    }
}
