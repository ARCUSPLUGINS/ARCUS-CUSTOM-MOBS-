package com.arcusmc.custommobs;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.Listener;

public class CustomMobs extends JavaPlugin {

    private MobManager mobManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        mobManager = new MobManager(this);

        Bukkit.getPluginManager().registerEvents(mobManager, this);
        Bukkit.getPluginManager().registerEvents(new Listener() {
            @org.bukkit.event.EventHandler
            public void onEntityDeath(EntityDeathEvent event) {
                LootManager.handleDeath(event);
            }
        }, this);

        new SpawnTask(this, mobManager).runTaskTimer(this, 20 * 60, 20 * 60);
        getLogger().info("CustomMobs fully enabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return false;

        Player player = (Player) sender;
        if (args.length == 0) {
            player.sendMessage("§cUse /custommob <zombie|skeleton|creeper>");
            return true;
        }

        mobManager.spawnCustomMob(player.getLocation(), args[0].toLowerCase());
        return true;
    }
}
