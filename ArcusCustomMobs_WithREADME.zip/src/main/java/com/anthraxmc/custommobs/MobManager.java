package com.arcusmc.custommobs;

import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class MobManager implements Listener {

    private final JavaPlugin plugin;

    public MobManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void spawnCustomMob(Location location, String type) {
        FileConfiguration config = plugin.getConfig();

        if (!config.contains("mobs." + type)) return;

        String name = ChatColor.translateAlternateColorCodes('&', config.getString("mobs." + type + ".name"));
        double health = config.getDouble("mobs." + type + ".health");

        EntityType entityType = EntityType.valueOf(type.toUpperCase());
        LivingEntity mob = (LivingEntity) location.getWorld().spawnEntity(location, entityType);

        mob.setCustomName(name);
        mob.setCustomNameVisible(true);
        mob.setMaxHealth(health);
        mob.setHealth(health);

        if (type.equals("zombie")) {
            mob.getEquipment().setHelmet(new ItemStack(Material.IRON_HELMET));
        }

        String skill = config.getString("mobs." + type + ".skill", "");
        if (skill.equalsIgnoreCase("explosion")) {
            SkillManager.castExplosionSkill(mob);
        } else if (skill.equalsIgnoreCase("lightning")) {
            SkillManager.castLightningSkill(mob);
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        spawnCustomMob(event.getPlayer().getLocation(), "zombie");
    }
}
