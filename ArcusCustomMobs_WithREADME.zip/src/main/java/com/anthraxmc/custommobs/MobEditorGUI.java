package com.arcusmc.custommobs;

import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class MobEditorGUI {

    public static Inventory createGUI(JavaPlugin plugin) {
        Inventory gui = plugin.getServer().createInventory(null, 9, "AN"); // GUI name: AN

        ItemStack zombie = new ItemStack(Material.SKULL_ITEM, 1, (short) 2);  // 2 = Zombie head
        ItemMeta zombieMeta = zombie.getItemMeta();
        zombieMeta.setDisplayName("§cEdit Zombie");
        zombie.setItemMeta(zombieMeta);

        ItemStack skeleton = new ItemStack(Material.BONE);
        ItemMeta skeletonMeta = skeleton.getItemMeta();
        skeletonMeta.setDisplayName("§fEdit Skeleton");
        skeleton.setItemMeta(skeletonMeta);

        gui.setItem(0, zombie);
        gui.setItem(1, skeleton);

        return gui;
    }
}
